create function check_room_exists() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM public."ПАЛАТА" p
    WHERE p."КОД_БОЛЬНИЦЫ" = NEW."КОД_БОЛЬНИЦЫ"
    AND p."НОМЕР_ПАЛАТЫ" = NEW."НОМЕР_ПАЛАТЫ"
  ) THEN RAISE EXCEPTION 'ЗАДАННОГО НОМЕРА_ПАЛАТЫ (УКАЗАНО: %) НЕ СУЩЕСТВУЕТ ВНУТРИ ВЫБРАННОЙ БОЛЬНИЦЫ (УКАЗАНО: %)',
  NEW."НОМЕР_ПАЛАТЫ", NEW."КОД_БОЛЬНИЦЫ";
  END IF;
  RETURN NEW;
END;
$$;

alter function check_room_exists() owner to postgres;

