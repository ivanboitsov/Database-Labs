create function check_default_hospital_beds() returns trigger
    language plpgsql
as
$$
BEGIN
NEW."ЧИСЛО_КОЕК" = 0;
    RETURN NEW;
END
$$;

alter function check_default_hospital_beds() owner to postgres;

