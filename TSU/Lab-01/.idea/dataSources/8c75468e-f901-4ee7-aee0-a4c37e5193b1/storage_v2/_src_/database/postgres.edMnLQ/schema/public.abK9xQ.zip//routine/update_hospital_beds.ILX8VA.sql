create function update_hospital_beds() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE public."БОЛЬНИЦА"
  SET "ЧИСЛО_КОЕК" = (
    SELECT SUM("ЧИСЛО_КОЕК")
    FROM public."ПАЛАТА" p
    WHERE p."КОД_БОЛЬНИЦЫ" = public."БОЛЬНИЦА"."КОД_БОЛЬНИЦЫ"
  ) WHERE "КОД_БОЛЬНИЦЫ" = NEW."КОД_БОЛЬНИЦЫ";

  RETURN NEW;
END
$$;

alter function update_hospital_beds() owner to postgres;

