create function check_bed_capacity() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW."НОМЕР_КОЙКИ" > (
        SELECT P."ЧИСЛО_КОЕК"
        FROM "ПАЛАТА" P
        WHERE P."КОД_БОЛЬНИЦЫ" = NEW."КОД_БОЛЬНИЦЫ" AND P."НОМЕР_ПАЛАТЫ" = NEW."НОМЕР_ПАЛАТЫ"
    ) THEN
        RAISE EXCEPTION 'НОМЕР КОЙКИ ПРЕВЫШАЕТ КОЛИЧЕСТВО КОЕК В ПАЛАТЕ';
    END IF;
    RETURN NEW;
END
$$;

alter function check_bed_capacity() owner to postgres;

