create function check_bed_limit() returns trigger
    language plpgsql
as
$$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM public."ПАЛАТА" p
    WHERE p."НОМЕР_ПАЛАТЫ" = NEW."НОМЕР_ПАЛАТЫ"
    AND p."ЧИСЛО_КОЕК" < NEW."НОМЕР_КОЙКИ"
  ) THEN RAISE EXCEPTION 'НОМЕР_КОЙКИ не может превышать ЧИСЛО_КОЕК в палате';
  END IF;
  RETURN NEW;
END;
$$;

alter function check_bed_limit() owner to postgres;

